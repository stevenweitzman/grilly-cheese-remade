
import plotly.graph_objects as go
import json

# Data
recipes = ["The Original", "The Gourmet", "The Veggie", "The Jalapeño Popper", 
           "The Fig & Basil", "The Avocado Dream", "The Apple Brie", 
           "The Caramelized Onion & Rosemary", "The Truffle Indulgence", 
           "The Spicy Sweet Peach", "The BBQ Bacon & Cheddar", "The Crispy Cheddar Crust"]

image_ids = ["generated_image:97", "generated_image:98", "generated_image:99", 
             "generated_image:100", "generated_image:101", "generated_image:102", 
             "generated_image:103", "generated_image:104", "generated_image:105", 
             "generated_image:106", "generated_image:107", "generated_image:108"]

# Create alternating row colors for all 12 rows
row_colors = ['#f8f9fa' if i % 2 == 0 else '#ffffff' for i in range(12)]

# Create figure
fig = go.Figure()

# Add a table using go.Table with improved formatting
fig.add_trace(go.Table(
    columnwidth=[200, 150],
    header=dict(
        values=['<b>Recipe Name</b>', '<b>Image ID</b>'],
        fill_color='#1FB8CD',
        align='left',
        font=dict(color='white', size=14, family='Arial'),
        height=40,
        line=dict(color='#13343B', width=1)
    ),
    cells=dict(
        values=[recipes, image_ids],
        fill_color=[row_colors, row_colors],
        align='left',
        font=dict(color='#13343B', size=12, family='Arial'),
        height=38,
        line=dict(color='#dee2e6', width=1)
    )
))

# Update layout to minimize whitespace
fig.update_layout(
    title={
        "text": "Recipe Image Reference Guide (12 Recipes)<br><span style='font-size: 18px; font-weight: normal;'>Complete list of recipe names with image identifiers</span>"
    }
)

# Save as PNG and SVG
fig.write_image("recipe_reference_guide.png")
fig.write_image("recipe_reference_guide.svg", format="svg")
