
import plotly.graph_objects as go

# Create recipe mapping data for all 12 recipes
recipes = [f"Recipe {i+1}" for i in range(12)]
array_indices = list(range(12))
url_references = [f"image_urls[{i}]" for i in array_indices]

# Create alternating row colors for 12 rows
row_colors = ['#B3E5EC' if i % 2 == 0 else 'white' for i in range(12)]

# Create a table-style visualization showing the mapping
fig = go.Figure(data=[go.Table(
    header=dict(
        values=['<b>Recipe</b>', '<b>Array Index</b>', '<b>URL Reference</b>'],
        fill_color='#1FB8CD',
        align='left',
        font=dict(color='white', size=14)
    ),
    cells=dict(
        values=[
            recipes,
            array_indices,
            url_references
        ],
        fill_color=[row_colors, row_colors, row_colors],
        align='left',
        font=dict(size=12),
        height=30
    )
)])

fig.update_layout(
    title={
        "text": "Recipe to Image Array Index Mapping (12 Recipes)<br><span style='font-size: 18px; font-weight: normal;'>Use array index to access corresponding image URL</span>"
    }
)

# Save as both PNG and SVG
fig.write_image("recipe_mapping.png")
fig.write_image("recipe_mapping.svg", format="svg")
